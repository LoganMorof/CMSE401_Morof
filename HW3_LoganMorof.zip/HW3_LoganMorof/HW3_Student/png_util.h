#ifndef __PNG_UTIL__
#define __PNG_UTIL__

#include <png.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct image_size_t {
  int width;
  int height;
} image_size_t;

image_size_t get_image_size(char* filename);
void read_png_file(char* filename, unsigned char* img, image_size_t img_size);
void write_png_file(char*, unsigned char* img, image_size_t img_size);

#ifdef __cplusplus
}
#endif

#endif // __PNG_UTIL__
