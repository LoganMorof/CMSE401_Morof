#!/bin/bash --login
#SBATCH --job-name=gol_cuda
#SBATCH --partition=gpu
#SBATCH --gpus=v100:1
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --time=00:10:00
#SBATCH --output=gol_cuda.out
#SBATCH --error=gol_cuda.err

module purge
module load CUDA/12.1.1

# Build CUDA version
make clean
make

# Benchmark for n=5, M=10,20,30
N=5
for M in 10 20 30; do
  echo "=== M=$M ==="
  time echo "$N $M" | ./gol
done
