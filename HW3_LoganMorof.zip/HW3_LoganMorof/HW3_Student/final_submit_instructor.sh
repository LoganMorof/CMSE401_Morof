#!/bin/bash --login
#SBATCH --job-name=gol_submit
#SBATCH --partition=gpu
#SBATCH --gpus=v100:1
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --time=00:10:00
#SBATCH --output=submit.out
#SBATCH --error=submit.err

module purge
module load CUDA/12.1.1

make clean
make
make test
