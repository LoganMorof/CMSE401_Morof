#!/bin/bash --login
#SBATCH --job-name=gol_cuda
#SBATCH --partition=gpu
#SBATCH --gpus=v100:1
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --time=00:10:00
#SBATCH --output=gol_cuda.out
#SBATCH --error=gol_cuda.err

module purge
module load CUDA/12.1.1

make clean
make
time ./gol < data.txt
