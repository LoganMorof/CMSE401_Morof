#!/bin/bash --login
#SBATCH --job-name=hw4_serial_bench
#SBATCH --output=serial_bench.%j.out
#SBATCH --error=serial_bench.%j.err
#SBATCH --time=4:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=2G
#SBATCH --partition=standard

module load gcc

# build/rebuild executables
make clean
make

EXE=revGOL
TARGET=cmse2.txt
RUNS=10

BEST_FIT=999999
BEST_SEED=0

echo "seed,fitness,time_sec" > serial_times.csv

for SEED in $(seq 1 $RUNS); do
  START=$(date +%s.%N)
  OUTPUT=$("./$EXE" $TARGET $SEED)
  END=$(date +%s.%N)

  ELAPSED=$(echo "$END - $START" | bc)
  FITNESS=$(echo "$OUTPUT" | grep "Result Fitness" | sed -E 's/.*Result Fitness=([0-9]+).*/\1/')

  echo "$SEED,$FITNESS,$ELAPSED" >> serial_times.csv

  if [ "$FITNESS" -lt "$BEST_FIT" ]; then
    BEST_FIT=$FITNESS
    BEST_SEED=$SEED
    echo "$OUTPUT" > serial_best.txt
  fi
done

AVG_TIME=$(awk -F, 'NR>1{sum+=$3; cnt++} END{printf "%.3f", sum/cnt}' serial_times.csv)

echo
echo "Average time: $AVG_TIME s"
echo "Best fitness: $BEST_FIT (seed $BEST_SEED)"
echo "See serial_times.csv and serial_best.txt"

