#include <mpi.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#define max_nodes 264
#define str_length 50

/* Compute fitness as number of mismatched cells */
int fitness(char * plate1, char * plate2, int n){
    int errors = 0;
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++){
            int idx = i * (n + 2) + j;
            errors += !plate1[idx] == plate2[idx];
        }
    }
    return errors;
}

/* Count live neighbors */
int live(int index, char * plate[2], int which, int n){
    return plate[which][index - n - 3]
         + plate[which][index - n - 2]
         + plate[which][index - n - 1]
         + plate[which][index - 1]
         + plate[which][index + 1]
         + plate[which][index + n + 1]
         + plate[which][index + n + 2]
         + plate[which][index + n + 3];
}

/* Do one GOL iteration, return new 'which' */
int iteration(char * plate[2], int which, int n){
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++){
            int idx = i * (n + 2) + j;
            int num = live(idx, plate, which, n);
            if (plate[which][idx])
                plate[!which][idx] = (num == 2 || num == 3);
            else
                plate[!which][idx] = (num == 3);
        }
    }
    return !which;
}

/* Print a plate to stdout if small enough */
void print_plate(char * plate, int n){
    if (n < 60) {
        for(int i = 1; i <= n; i++){
            for(int j = 1; j <= n; j++){
                printf("%d", (int)plate[i*(n+2)+j]);
            }
            printf("\n");
        }
    } else {
        printf("Plate too large to print to screen\n");
    }
    printf("\0");
}

/* Initialize plate with mostly random bits */
void makerandom(char * plate, int n) {
    memset(plate, 0, (n+2)*(n+2));
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
            plate[i*(n+2)+j] = (rand() % 100) > 10;
}

/* Mutate based on best_plate with given rate */
void mutate(char * plate, char * best_plate, int n, int rate) {
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++){
            int idx = i*(n+2)+j;
            if ((rand() % 100) < rate)
                plate[idx] = rand() % 2;
            else
                plate[idx] = best_plate[idx];
        }
}

/* Single-point crossover */
void cross(char * plate1, char * plate2, int n) {
    int total = (n+2)*(n+2);
    int cp = rand() % total;
    int start = (cp < total/2) ? 0 : cp;
    int end   = (cp < total/2) ? cp : total;
    for(int i = start; i <= end; i++)
        plate1[i] = plate2[i];
}

/* Read target plate from file */
char * readplate(char * filename, int *n) {
    FILE *fp = fopen(filename, "r");
    if (!fp) { perror("fopen"); exit(EXIT_FAILURE); }
    int M, N;
    fscanf(fp, "%d %d", &N, &M);
    *n = N;
    char * plate = calloc((N+2)*(N+2), 1);
    char line[N+1];
    for(int i = 1; i <= N; i++){
        fscanf(fp, "%s", line);
        for(int j = 0; j < N; j++)
            plate[i*(N+2)+j+1] = (line[j] == '1');
    }
    fclose(fp);
    return plate;
}

int main(int argc, char *argv[]) {
    int which = 0, n, npop = 10000, ngen = 1000, M = 0, rand_seed;
    time_t t;

    /* --- MPI INIT --- */
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    /* Seed RNG uniquely per rank */
    if (argc > 2) rand_seed = (atoi(argv[2]) + 1) * 7;
    else          rand_seed = time(&t);
    srand(rand_seed);
    printf("Rank %d/%d seed=%d\n", rank, size, rand_seed);

    /* Read input target */
    char * target = readplate(argv[1], &n);
    char * buffer = calloc((n+2)*(n+2), 1);

    /* Initialize GA population */
    char * population[npop];
    int popfit[npop];
    for(int i = 0; i < npop; i++){
        popfit[i] = n*n;
        population[i] = calloc((n+2)*(n+2), 1);
        if (i < npop/2) mutate(population[i], target, n, 10);
        else            makerandom(population[i], n);
    }
    int best = 0, sbest = 1;

    /* Buffers for neighbor exchange */
    int ps = (n+2)*(n+2);
    char * neighbor_plate = malloc(ps);
    int neighbor_fit;

    /* MAIN GA LOOP */
    for(int g = 0; g < ngen; g++){
        /* Evaluate population */
        for(int i = 0; i < npop; i++){
            char * plates[2] = { population[i], buffer };
            which = iteration(plates, which, n);
            popfit[i] = fitness(buffer, target, n);
            if (popfit[i] < popfit[best]) {
                sbest = best;
                best  = i;
            } else if (sbest == best) {
                sbest = i;
            }
        }
        if (rank == 0)
            printf("Gen %d: rank0 best-fit=%d\n", g, popfit[best]);

        /* NEIGHBOR EXCHANGE */
        int prev = (rank - 1 + size) % size;
        int next = (rank + 1) % size;
        int my_fit = popfit[best];

        if (rank == 0) {
            MPI_Recv(&neighbor_fit,   1, MPI_INT,  prev, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Recv(neighbor_plate,  ps, MPI_CHAR, prev, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Send(&my_fit,         1, MPI_INT,  next, 0, MPI_COMM_WORLD);
            MPI_Send(population[best],ps, MPI_CHAR, next, 1, MPI_COMM_WORLD);
        } else {
            MPI_Send(&my_fit,         1, MPI_INT,  next, 0, MPI_COMM_WORLD);
            MPI_Send(population[best],ps, MPI_CHAR, next, 1, MPI_COMM_WORLD);
            MPI_Recv(&neighbor_fit,   1, MPI_INT,  prev, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Recv(neighbor_plate,  ps, MPI_CHAR, prev, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        /* If neighbor is better, adopt their plate */
        if (neighbor_fit < my_fit) {
            int old_best = best;
            memcpy(population[best], neighbor_plate, ps);
            popfit[best] = neighbor_fit;
            sbest = old_best;
        }

        /* Reproduce next generation */
        int rate = (popfit[best] * 100) / (n*n);
        for(int i = 0; i < npop; i++){
            if      (i == sbest)                cross(population[i], population[best], n);
            else if (i < npop/3)                mutate(population[i], target, n, rate);
            else if (i < 2*npop/3)              cross(population[i], population[best], n);
            else                                makerandom(population[i], n);
        }
    }

    free(neighbor_plate);

    /* FINAL CONSOLIDATION */
    int local_fit = popfit[best];
    char * local_plate = population[best];

    if (rank != 0) {
        MPI_Send(&local_fit,   1, MPI_INT,  0, 0, MPI_COMM_WORLD);
        MPI_Send(local_plate,  ps, MPI_CHAR, 0, 1, MPI_COMM_WORLD);
    } else {
        int global_fit = local_fit;
        char * best_plate = malloc(ps);
        memcpy(best_plate, local_plate, ps);
        for(int src = 1; src < size; src++){
            int recv_fit;
            char * recv_plate = malloc(ps);
            MPI_Recv(&recv_fit,   1, MPI_INT,  src, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Recv(recv_plate,  ps, MPI_CHAR, src, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            if (recv_fit < global_fit) {
                global_fit = recv_fit;
                memcpy(best_plate, recv_plate, ps);
            }
            free(recv_plate);
        }
        printf("=== GLOBAL BEST FITNESS=%d ===\n", global_fit);
        print_plate(best_plate, n);
        free(best_plate);
    }

    MPI_Finalize();

    /* Cleanup */
    free(target);
    free(buffer);
    for(int i = 0; i < npop; i++) free(population[i]);

    return 0;
}

